import { Note } from '@/types'

export default function KnowledgeBase({ notes, onRefresh }: { notes: Note[], onRefresh: () => void }) {
  return <div>KnowledgeBase Component Stub</div>
}
