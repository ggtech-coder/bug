import { Report } from '@/types'

export default function ReportGenerator({ reports, onRefresh }: { reports: Report[], onRefresh: () => void }) {
  return <div>ReportGenerator Component Stub</div>
}
