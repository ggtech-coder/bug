import { Vulnerability } from '@/types'

export default function VulnWorkspace({ vulnerabilities, onRefresh }: { vulnerabilities: Vulnerability[], onRefresh: () => void }) {
  return <div>VulnWorkspace Component Stub</div>
}
