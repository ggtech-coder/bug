import { AnalysisResult } from '@/types'

export default function ResultsView({ analysis }: { analysis: AnalysisResult }) {
  return <div>ResultsView Component Stub</div>
}
